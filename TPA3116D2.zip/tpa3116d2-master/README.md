# tpa3116d2
I designed an audio power amplifier board based around the tpa3116d2. I chose the highest possible oscilator frequency of 1200khz. Many chinese designs feature no output LC filter which may result in power losses and lower efficiency. Because of that I chose higher grade components that are included in the output filter. My design also includes a large heat spreder, whitch may come in handy when dealing with a version of the IC that has a bottom mounted heat pad. My design also include loads of vias at the adge of the PCB which take care of high frequency interference.

The ampflifier is capable of delivering 50W to a singe channel load (4ohm).
